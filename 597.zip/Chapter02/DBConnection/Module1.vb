Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()
        Dim dbConnection As SqlConnection
        Dim dataSource As String = "SARATOGA\VSTE"
        Dim database As String = "Northwind"

        ' Lets set up the connection ready to go
        dbConnection = New SqlConnection("Data Source=" & dataSource + _
                    ";Integrated Security=sspi;" + _
                    "Initial Catalog=" + database)
        Try
            ' Go ahead and open up the connection
            dbConnection.Open()

            WriteLine("Database connection established.")
            WriteLine("Database is version " + dbConnection.ServerVersion.ToString)
            WriteLine("Your workstation is " + dbConnection.WorkstationId.ToString)

            ' Finally, close the connection down
            dbConnection.Close()

        Catch ex As Exception
            ' An exception occurred, so let's elegantly present it
            WriteLine("An error occurred connecting to the database")
            WriteLine(ex.ToString)
        End Try

        ' To stop the console window vanishing when the app finishes, 
        ' prompt the user to hit a key
        WriteLine("Hit Return to continue")
        ReadLine()
    End Sub
End Module
