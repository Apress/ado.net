Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Sub Main()
        ' Set up the connection object ready to hit the database
        Dim dbConnection As SqlConnection = _
            New SqlConnection("Data Source=SARATOGA\VSTE;Integrated Security=sspi;" + _
                "Initial Catalog=Northwind")

        ' Set up a command object to go and run our query
        Dim employeeCommand As SqlCommand = New _
            SqlCommand("SELECT EmployeeID, LastName, FirstName  FROM Employees", _
                dbConnection)
        Try
            ' Open the connection to the database and the command
            ' against it to give us a reader.
            dbConnection.Open()
            Dim reader As SqlDataReader = employeeCommand.ExecuteReader()

            ' Make sure that we have more records to read,
            ' and then start looping through them
            Dim bMoreRecords As Boolean = reader.Read()

            Do While bMoreRecords
                WriteLine("Employee ID " + reader.GetValue(0).ToString() + _
                    ", First name " + reader.GetValue(1).ToString() + _
                    ", Last name " + reader.GetValue(2).ToString())
                bMoreRecords = reader.Read()
            Loop
            reader.Close()

            'Finally, close the connection down.
            dbConnection.Close()

        Catch ex As Exception
            WriteLine("A problem occurred...")
            WriteLine(ex.ToString())
        End Try

        ' Ask the user to hit a key so the console window doesn't just vanish
        WriteLine("Hit return to continue")
        ReadLine()
    End Sub
End Module
