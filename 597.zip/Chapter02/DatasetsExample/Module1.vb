Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()

        ' Just as always, set up the connection first. 
        Dim dbConnection As SqlConnection = _
            New SqlConnection("Data Source=localhost;Integrated Security=sspi;" + _
                "Initial Catalog=Northwind")

        ' Similar to using a data reader, we need to build a command using our connection
        ' to grab the data we're interested in.
        Dim employeeCommand As SqlCommand = _
            New SqlCommand("SELECT * from Employees", _
                dbConnection)

        ' Now we can go ahead and create a data-adapter - this will be used to automatically
        ' populate our dataset. 
        Dim nwDataAdapter As SqlDataAdapter = _
            New SqlDataAdapter(employeeCommand)

        Try
            WriteLine("Opening the database connection.")
            dbConnection.Open()

            Dim nwDataSet As DataSet = New DataSet()
            WriteLine("Filling the dataset.")
            nwDataAdapter.Fill(nwDataSet)
            dbConnection.Close()

            ' Even though the connection has been closed, we can still interrogate our 
            ' dataset, and even navigate through it if necessary.
            WriteLine("The dataset contains " + nwDataSet.Tables.Count.ToString() + " table(s).")
            WriteLine("The first datatable consists of " + nwDataSet.Tables(0).Rows.Count.ToString() + _
                " rows, each holding " + nwDataSet.Tables(0).Columns.Count.ToString() + _
                " columns of data:")

            ' Let's walk through the columns collection and find out a little more 
            ' about them. 
            Dim employeeColumn As DataColumn
            For Each employeeColumn In nwDataSet.Tables(0).Columns
                Write("    " + employeeColumn.ColumnName)
                WriteLine(" (" + employeeColumn.DataType.ToString() + ")")
            Next

            ' We can also walk through the rows collection and the columns collection
            ' together to print the value of every field in the table
            Dim employeeRow As DataRow
            For Each employeeRow In nwDataSet.Tables(0).Rows
                For Each employeeColumn In nwDataSet.Tables(0).Columns
                    Write(employeeRow.Item(employeeColumn.Ordinal))
                Next
                WriteLine(" ")
            Next

        Catch ex As Exception
            WriteLine("An exception occurred...")
            WriteLine(ex.ToString)
        End Try

        WriteLine("Hit return to continue")
        ReadLine()

    End Sub
End Module
