Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Sub Main()
        Dim connection As SqlConnection = New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        Dim command As SqlCommand = New SqlCommand( _
            "SELECT * FROM Employees", connection)

        Try
            connection.Open()
            Dim reader As SqlDataReader = command.ExecuteReader()

            WriteLine("Data types in the Employee table")

            ' The reader needs to be positioned on a valid row in order to 
            ' interrogate the columns in that row, so we need to do a Read()
            reader.Read()



            ' Loop through the items in the result set. FieldCount tells us how 
            ' many items there are, but the items are referenced starting at item 0 
            Dim itemIndex As Integer
            For itemIndex = 0 To reader.FieldCount - 1
                WriteLine(reader.Item(itemIndex).GetType().ToString)
            Next

            reader.Close()
            connection.Close()

        Catch ex As Exception
            WriteLine("There was a problem with the code... " + ex.ToString())
        End Try
        WriteLine("All done. Hit return to exit")
        ReadLine()
    End Sub
End Module
