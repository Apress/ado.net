Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Sub Main()

        Dim connection As SqlConnection = New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        Dim command As SqlCommand = New SqlCommand( _
            "SELECT * FROM Employees", connection)

        Try
            connection.Open()
            Dim reader As SqlDataReader = command.ExecuteReader()

            WriteLine("Iterating through the Employee records")

            ' Declare a DBDataRecord object so that we can easily iterate the rows
            ' in the SqlDataReader.
            Dim dataRecord As Common.DbDataRecord

            ' Isn't this so much nicer than that nasty old Do While reader.Read() loop
            For Each dataRecord In reader
                WriteLine(dataRecord.GetValue(1).ToString() + " " + _
dataRecord.GetValue(2).ToString())
            Next

            reader.Close()
            connection.Close()

        Catch ex As Exception
            WriteLine("There was a problem with the code... " + ex.ToString())
        End Try
        WriteLine("All done. Hit return to exit")
        ReadLine()

    End Sub
End Module
