Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()

        Dim con As SqlConnection = New SqlConnection( _
            "Data Source=SARATOGA\VSTE;Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")

        Dim command As SqlCommand = New SqlCommand( _
            "UPDATE Customers SET Country='United Kingdom' WHERE Country='UK'", _
            con)

        Try
            con.Open()

            WriteLine("Rows affects = " + command.ExecuteNonQuery().ToString())

            command.CommandText = "UPDATE Customers SET Country='UK' " + _
                "WHERE Country='United Kingdom'"
            WriteLine("Resetting data - rows affected = " + _
                command.ExecuteNonQuery().ToString())

            con.Close()
        Catch ex As Exception
            WriteLine("An error occurred... " + ex.ToString())
        End Try

        WriteLine("Hit return to exit.")
        ReadLine()
    End Sub

End Module
