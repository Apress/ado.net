Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1
    Sub Main()

        ' First up, set up the connection and command
        Dim connection As SqlConnection = New SqlConnection("Data Source=localhost;" + _
            "Initial Catalog=Northwind;Integrated Security=SSPI")
        Dim command As SqlCommand = New SqlCommand( _
            "SELECT COUNT(*) FROM Customers WHERE Country = @Country", _
            connection)

        Try
            ' Open our connection ready to go
            connection.Open()

            Dim customerCount As Integer

            ' Add the @Country parameter to the parameter list, with a value of "UK"
            command.Parameters.Add("@Country", "UK")

            'Run the query and grab the result
            customerCount = CType(command.ExecuteScalar(), Integer)
            WriteLine("There are " + customerCount.ToString() + " customers in the UK")

            ' Now change that @Country parameter's value - you can refer
            ' to a SqlParameter in the Parameters collection by name
            command.Parameters("@Country").Value = "Germany"
            customerCount = CType(command.ExecuteScalar(), Integer)
            WriteLine("and there are " + customerCount.ToString() + " customers in Germany")

            ' Finally, don't forget to close down that connection
            connection.Close()

        Catch ex As Exception
            WriteLine("There was a problem with the code..." + _
                ex.ToString())
        End Try

        Console.ReadLine()

    End Sub

End Module
