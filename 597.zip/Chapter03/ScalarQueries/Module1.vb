Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()

        Dim con As SqlConnection = New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")

        Dim command As SqlCommand = New SqlCommand( _
            "SELECT Count(*) FROM Customers WHERE Country='UK'", _
            con)

        Try
            con.Open()

            WriteLine("There are " + _
                command.ExecuteScalar().ToString() + _
                " customers in the UK in the database.")

            con.Close()
        Catch ex As Exception
            WriteLine("An error occurred... " + ex.ToString())
        End Try

        WriteLine("Hit return to exit.")
        ReadLine()
    End Sub
End Module
