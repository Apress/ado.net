Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()
        Dim connection As SqlConnection = New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")
        Dim command As SqlCommand = New SqlCommand("Employee Sales By Country", connection)
        command.CommandType = CommandType.StoredProcedure

        Try
            command.Parameters.Add("@Beginning_Date", #7/1/1996#)
            command.Parameters.Add("@Ending_Date", #8/1/1996#)

            connection.Open()

            Dim reader As SqlDataReader = command.ExecuteReader()

            Dim nIndex As Integer

            Do While reader.Read()
                For nIndex = 0 To reader.FieldCount - 1
                    Write(reader.GetValue(nIndex).ToString + " ")
                Next
                WriteLine("")
            Loop

            reader.Close()
            connection.Close()

        Catch ex As Exception
            WriteLine("There was a problem with the code..." + _
                ex.ToString())
        End Try

        WriteLine("All done - hit return to exit")
        ReadLine()

    End Sub

End Module
