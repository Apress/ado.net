Option Strict On
Imports System.Console

Module Module1

    Sub Main()

        WriteLine("Creating the 'Pets' table...")
        Dim petsTable As DataTable = New DataTable("Pets")

        WriteLine("Adding columns into the table")
        petsTable.Columns.Add("PetName", System.Type.GetType("System.String"))
        petsTable.Columns.Add("Breed", System.Type.GetType("System.String"))
        petsTable.Columns.Add("Age", System.Type.GetType("System.Int16"))

        ' Let's interrogate the columns now to find out more about them
        WriteLine("There are now " + petsTable.Columns.Count.ToString() + _
            " columns in the table")
        Dim currentColumn As DataColumn
        For Each currentColumn In petsTable.Columns
            WriteLine("Column Name : " + currentColumn.ColumnName + ", Type : " + _
                currentColumn.DataType.ToString() + _
                ", Ordinal : " + currentColumn.Ordinal.ToString())
        Next

        ' Let's add some values into the table now
        petsTable.Rows.Add(New Object() {"Frisky", "Tortoise", 112})
        petsTable.Rows.Add(New Object() {"Fluffy", "Grizzly Bear", 6})
        petsTable.Rows.Add(New Object() {"Spike", "Hamster", 1})

        WriteLine("There are now " + petsTable.Rows.Count.ToString() + _
            "rows in the table")
        Dim currentRow As DataRow
        For Each currentRow In petsTable.Rows
            WriteLine(currentRow.Item(0).ToString() + ", " + _
                currentRow.Item(1).ToString() + _
                ", " + currentRow.Item(2).ToString())
        Next

        WriteLine("All done. Press Enter to exit")
        ReadLine()
    End Sub

End Module

