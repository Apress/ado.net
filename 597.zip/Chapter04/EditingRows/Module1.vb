Option Strict On
Imports System.Console

Module Module1

    Sub Main()

        Dim newTable As DataTable = CreateTable()
        AddRows(newTable)

        Dim thePet As DataRow = newTable.Rows(0)
        ' Print out the new row
        PrintRow(thePet)

        Write("What breed should Snuggles really be ? ")
        Dim newBreed As String = ReadLine()

        ' Ok, put the new row into edit mode
        thePet.BeginEdit()
        ' Change the breed of the pet to the value entered by the user.
        thePet.Item("Breed") = newBreed
        ' Finally, end edit mode, which stores the changes in the table.
        thePet.EndEdit()

        ' Now print out the new pet details
        PrintRow(thePet)

        WriteLine("All done. Press Enter to exit")
        ReadLine()

    End Sub

    ' CreateTable() 
    ' Creates our Pets table, holding PetNames, Breed and Age.
    Private Function CreateTable() As DataTable
        Dim newTable As DataTable = New DataTable("Pets")
        ' Use a with clause to simplify the code when adding the 
        ' columns into the table. 
        With newTable.Columns
            .Add("PetName", System.Type.GetType("System.String"))
            .Add("Breed", System.Type.GetType("System.String"))
            .Add("Age", System.Type.GetType("System.Int16"))
        End With
        ' Now that we're done with the table, we can return it 
        ' out of the function to the main() routine.
        Return newTable
    End Function

    ' AddRows( DataTable ) 
    ' Adds a single row into the table to hold details of our
    ' sample pet, Snuggles - the Reticulated Python.
    Private Sub AddRows(ByVal theTable As DataTable)
        Dim newRow As DataRow = theTable.NewRow()
        newRow.Item("PetName") = "Snuggles"
        newRow.Item("Breed") = "Reticulated Python"
        newRow.Item("Age") = 10
        theTable.Rows.Add(newRow)
    End Sub

    ' PrintRow( DataRow )
    ' Prints out the pet name, breed and age from a DataRow passed into 
    ' the method.
    Private Sub PrintRow(ByVal theRow As DataRow)
        WriteLine(theRow.Item("PetName").ToString() + " is a " + _
            theRow.Item("Breed").ToString() + _
            " aged " + theRow.Item("Age").ToString())
    End Sub

End Module
