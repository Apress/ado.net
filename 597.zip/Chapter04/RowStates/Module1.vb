Option Strict On
Imports System.Console


Module Module1

    Sub Main()

        ' First, create the table
        Dim newTable As DataTable = New DataTable("TestTable")
        newTable.Columns.Add("Name", System.Type.GetType("System.String"))

        ' Now add in a row
        Dim newRow As DataRow = newTable.NewRow
        newRow("Name") = "Peter"
        WriteLine("The row's state after creation is " + newRow.RowState.ToString())

        newTable.Rows.Add(newRow)
        WriteLine("The row's state after adding to the table is " + _
            newRow.RowState.ToString())

        newTable.Rows.Remove(newRow)
        WriteLine("The row's state after removing it from the table is " + _
            newRow.RowState.ToString())

        newTable.Rows.Add(newRow)

        newTable.AcceptChanges()
        WriteLine("The row's state after accepting changes is " + _
            newRow.RowState.ToString())

        newRow("Name") = "Gary"
        WriteLine("After changing a column's value, the state is " + _
            newRow.RowState.ToString())

        newRow.Delete()
        WriteLine("Deleting a row changes the row state to " + _
            newRow.RowState.ToString())

        newTable.RejectChanges()
        WriteLine("After rejecting the changes, the row's state becomes " + _
            newRow.RowState.ToString())

        WriteLine("All done. Press Enter to exit")
        ReadLine()

    End Sub

End Module
