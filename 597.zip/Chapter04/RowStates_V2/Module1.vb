Option Strict On
Imports System.Console


Module Module1

    Sub Main()

        ' First, create the table
        Dim newTable As DataTable = New DataTable("TestTable")
        newTable.Columns.Add("Name", System.Type.GetType("System.String"))

        ' Now add in a row
        Dim newRow As DataRow = newTable.NewRow
        newRow("Name") = "Peter"
        PrintRowDetails(newRow)

        newTable.Rows.Add(newRow)
        PrintRowDetails(newRow)

        newTable.Rows.Remove(newRow)
        PrintRowDetails(newRow)
        newTable.Rows.Add(newRow)


        newTable.AcceptChanges()
        PrintRowDetails(newRow)

        newRow("Name") = "Gary"
        PrintRowDetails(newRow)

        newRow.Delete()
        PrintRowDetails(newRow)

        newTable.RejectChanges()
        PrintRowDetails(newRow)

        WriteLine("All done. Press Enter to exit")
        ReadLine()

    End Sub

    Private Sub PrintRowDetails(ByVal newRow As DataRow)

        WriteLine("------The row's current state is " + newRow.RowState.ToString())
        If newRow.HasVersion(DataRowVersion.Current) Then
            WriteLine("The current version of the row is " + _
                newRow("Name", DataRowVersion.Current).ToString())
        Else
            WriteLine("There is no 'current' version of the row available")
        End If

        If newRow.HasVersion(DataRowVersion.Default) Then
            WriteLine("The default version of the row is " + _
                newRow("Name", DataRowVersion.Default).ToString())
        Else
            WriteLine("There is no 'default' version of the row available")
        End If

        If newRow.HasVersion(DataRowVersion.Original) Then
            WriteLine("The original version of the row is " + _
                newRow("Name", DataRowVersion.Original).ToString())
        Else
            WriteLine("There is no 'original' version of the row available")
        End If

        If newRow.HasVersion(DataRowVersion.Proposed) Then
            WriteLine("The proposed version of the row is " + _
                newRow("Name", DataRowVersion.Proposed).ToString())
        Else
            WriteLine("There is no proposed version of the row available")
        End If

    End Sub

End Module
