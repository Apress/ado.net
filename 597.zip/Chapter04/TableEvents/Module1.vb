Option Strict On
Imports System.Console


Module Module1

    Sub Main()

        Dim newTable As DataTable = New DataTable("TestTable")
        newTable.Columns.Add("ID", System.Type.GetType("System.Int16"))
        newTable.Columns.Add("Name", System.Type.GetType("System.String"))

        ' Add the event handlers
        AddHandler newTable.RowChanged, New DataRowChangeEventHandler(AddressOf Row_Changed)
        AddHandler newTable.RowDeleted, New DataRowChangeEventHandler(AddressOf Row_Changed)
        AddHandler newTable.RowChanging, New DataRowChangeEventHandler(AddressOf Row_Changing)
        AddHandler newTable.RowDeleting, New DataRowChangeEventHandler(AddressOf Row_Changing)

        Dim newRow As DataRow = newTable.NewRow()
        newRow("ID") = 1
        newRow("Name") = "Dog"
        newTable.Rows.Add(newRow)
        newTable.AcceptChanges()

        newRow.Delete()
        newTable.AcceptChanges()

        WriteLine("All done. Press Enter to exit")
        ReadLine()
    End Sub

    Private Sub Row_Changed(ByVal Sender As Object, ByVal args As DataRowChangeEventArgs)
        WriteLine("EVENT : Something has happened to a row")
        If args.Row.HasVersion(DataRowVersion.Current) Then
            WriteLine(args.Action.ToString + " " + _
                args.Row("ID").ToString() + args.Row("Name").ToString())
        Else
            WriteLine("Action was " + args.Action.ToString() + ", no current row available")
        End If
    End Sub

    Private Sub Row_Changing(ByVal Sender As Object, ByVal args As DataRowChangeEventArgs)
        WriteLine("EVENT : Something is currently happening to a row")
        If args.Row.HasVersion(DataRowVersion.Current) Then
            WriteLine(args.Action.ToString + " " + _
                args.Row("ID").ToString() + args.Row("Name").ToString())
        Else
            WriteLine("Action was " + args.Action.ToString() + _
                ", no current row available")
        End If
    End Sub

End Module

