Option Strict On
Imports System.Console


Module Module1

    Sub Main()
        Dim peopleTable As DataTable = New DataTable("People")
        peopleTable.Columns.Add("FirstName", System.Type.GetType("System.String"))
        peopleTable.Columns.Add("LastName", System.Type.GetType("System.String"))
        peopleTable.Columns.Add("Email", System.Type.GetType("System.String"))

        ' Use a calculated field to work out a simple email address (not a good way of
        ' doing things in a live app thanks to the risk of duplicates
        peopleTable.Columns("Email").Expression = _
            "LastName + substring(FirstName,1,1) + " + _
            "'@apress.com'"

        ' Set up the primary key to be a combination of lastname and firstname
        peopleTable.PrimaryKey = New DataColumn() _
            {peopleTable.Columns("LastName"), _
            peopleTable.Columns("FirstName")}

        ' Add some rows to the table
        Dim newPerson As DataRow = peopleTable.NewRow()
        newPerson("FirstName") = "Joe"
        newPerson("LastName") = "McAllister"
        peopleTable.Rows.Add(newPerson)

        newPerson = peopleTable.NewRow()
        newPerson("FirstName") = "Mike"
        newPerson("LastName") = "Zebra"
        peopleTable.Rows.Add(newPerson)

        newPerson = peopleTable.NewRow()
        newPerson("FirstName") = "Zara"
        newPerson("LastName") = "Armadillo"
        peopleTable.Rows.Add(newPerson)

        ' Use select to grab the rows in primary key order 
        ' (since we have a primary key) and print out the information
        For Each newPerson In peopleTable.Select()
            WriteLine(newPerson("Email").ToString() + " " + _
                newPerson("FirstName").ToString() + _
                " " + newPerson("LastName").ToString())
        Next

        WriteLine("All done. Press Enter to exit")
        ReadLine()

    End Sub

End Module