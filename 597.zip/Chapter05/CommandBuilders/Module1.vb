Option Strict On
Imports System.Data.SqlClient
Imports System.Console
Module Module1

    Sub Main()

        ' Build up a really quick data adapter. Let the data adapter build the 
        ' connection object, and set up the SelectCommand property
        Dim adapter As New SqlDataAdapter( _
            "Select * from Employees", _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        ' Attach that adapter to a SqlCommandBuilder - it can worry about the other
        ' commands we'll need
        Dim builder As New SqlCommandBuilder(adapter)

        Dim ds As New DataSet("Employees")
        adapter.Fill(ds)

        ' Here's where your code to make changes will go. 

        ' Let's take a look at what the command builder did
        WriteLine("The Update command...")
        WriteLine(builder.GetUpdateCommand().CommandText)

        ReadLine()
        WriteLine("The Insert command...")
        WriteLine(builder.GetInsertCommand().CommandText)

        ReadLine()
        WriteLine("The Delete command...")
        WriteLine(builder.GetDeleteCommand().CommandText)

        WriteLine("All done. Press Enter to exit")
        ReadLine()


    End Sub

End Module
