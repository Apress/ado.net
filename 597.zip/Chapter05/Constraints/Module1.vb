Option Strict On
Imports System.Console


Module Module1

    Sub Main()

        ' First define a simple table
        Dim contactTable As DataTable = New DataTable("Contacts")
        contactTable.Columns.Add( _
                    New DataColumn("EmpID", System.Type.GetType("System.String")))
        contactTable.Columns.Add( _
            New DataColumn("Name", System.Type.GetType("System.String")))

        ' Create a unique constraint on the employee ID column
        contactTable.Constraints.Add( _
            New UniqueConstraint("UniqueEmpID", contactTable.Columns("EmpID")))

        ' Now go ahead and add some rows of data
        Dim newContact As DataRow = contactTable.NewRow()
        newContact("EmpID") = "PJW"
        newContact("Name") = "Peter Wright"
        contactTable.Rows.Add(newContact)

        ' The following new row has the same value in EmpID as the previous
        ' row. This will throw an exception
        newContact = contactTable.NewRow()
        newContact("EmpID") = "PJW"
        newContact("Name") = "Paul John Williams"
        contactTable.Rows.Add(newContact)

    End Sub

End Module
