Option Strict On
Imports System.Data.SqlClient
Imports System.Console


Module Module1

    Sub Main()

        Try
            ' Create a data adapter to do the reading and writing
            Dim adapter As SqlDataAdapter = New SqlDataAdapter( _
                "SELECT RegionID, RegionDescription FROM Region", _
                "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

            ' Add in an Insert command - use the Select command's connection
            adapter.InsertCommand = New SqlCommand( _
                "INSERT INTO Region (RegionID, RegionDescription) VALUES (@ID, @Description)", _
                adapter.SelectCommand.Connection)

            ' Add the two parameters into the Insert command
            adapter.InsertCommand.Parameters.Add("@Description", SqlDbType.NChar, 50, "RegionDescription")
            adapter.InsertCommand.Parameters.Add("@ID", SqlDbType.Int, 4, "RegionID")

            ' Create a dataset and ask our adapter to fill it
            Dim ds As DataSet = New DataSet()
            adapter.Fill(ds)

            ds.Tables(0).Rows.Add(New Object() {99, "Somewhereville"})
            adapter.Update(ds)

        Catch ex As Exception
            WriteLine("There was a serious problem... ")
            WriteLine(ex.ToString())
        End Try

        WriteLine("All done. Press Enter to exit")
        ReadLine()
    End Sub

End Module
