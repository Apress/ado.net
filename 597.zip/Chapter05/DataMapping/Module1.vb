Option Strict On
Imports System.Data.SqlClient
Imports System.Console
Imports System.Data.Common


Module Module1

    Sub Main()

        ' First create a dataadapter and dataset to hold employee info from Northwind
        Dim NorthWindAdapter As New SqlDataAdapter( _
            "SELECT LastName, FirstName FROM employees", _
            "Data Source=Localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        Dim ds As New DataSet("EmployeeInfo")
        NorthWindAdapter.Fill(ds, "Employees")

        WriteLine("After selecting from Northwind, we have " + _
            ds.Tables("Employees").Rows.Count.ToString() + " employees.")

        ' Now create a dataadapter that maps employee info from the pubs database
        ' into our in memory table with employees from Northwind
        Dim PubsAdapter As New SqlDataAdapter( _
            "SELECT lname, fname FROM employee", _
            "Data Source=localhost;Initial Catalog=Pubs;Integrated Security=SSPI")

        Dim pubsMapping As DataTableMapping = _
            PubsAdapter.TableMappings.Add("employee", "Employees")
        pubsMapping.ColumnMappings.Add("lname", "LastName")
        pubsMapping.ColumnMappings.Add("fname", "FirstName")


        ' Finally, add the info from the pubs employee list to our own 
        ' Northwind list
        PubsAdapter.Fill(ds, "Employees")

        WriteLine("After selecting from Pubs, we now have " + _
            ds.Tables("Employees").Rows.Count.ToString() + " employees.")

        WriteLine("There are " + ds.Tables.Count.ToString() + " tables")

        WriteLine("All done. Press Enter to exit")
        ReadLine()
    End Sub

End Module
