Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()

        ' First, create a connection that we can use to get at the two tables
        Dim connection As SqlConnection = New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")
        Try
            ' Create a data adapter to deal with the order records
            Dim ordersAdapter As SqlDataAdapter = New SqlDataAdapter( _
                "SELECT * FROM Orders", connection)
            ' Create a data adapter to deal with the order detail records
            Dim orderDetailsAdapter As SqlDataAdapter = New SqlDataAdapter( _
                "SELECT * FROM [Order Details]", connection)

            ' Create an empty dataset, and then...
            Dim orderDataset As DataSet = New DataSet("Orders")
            ' ...add in the orders table and ...
            ordersAdapter.Fill(orderDataset, "Orders")
            ' ...the OrderDetails table into it.
            orderDetailsAdapter.Fill(orderDataset, "OrderDetails")

            ' Build a Datarelation to link the Orders and OrderDetails, 
            ' and store that relation in the dataset.
            orderDataset.Relations.Add(New DataRelation( _
                "OrderDetails", orderDataset.Tables("Orders").Columns("OrderID"), _
                orderDataset.Tables("OrderDetails").Columns("OrderID")))

            ' Now, find the first order and print details of all its order
            ' lines.
            Dim order As DataRow = orderDataset.Tables("Orders").Rows(0)
            Dim orderLine As DataRow
            For Each orderLine In order.GetChildRows("OrderDetails")
                Dim detailColumn As DataColumn
                For Each detailColumn In orderDataset.Tables("OrderDetails").Columns
                    WriteLine(detailColumn.ColumnName + " : " + _
                        orderLine.Item(detailColumn.Ordinal).ToString())
                Next
                WriteLine()
            Next

        Catch ex As Exception
            WriteLine("Something nasty happened")
            WriteLine(ex.ToString())
        End Try

        WriteLine("All done. Press Enter to exit.")
        ReadLine()

    End Sub

End Module

