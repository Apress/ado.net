Option Strict On
Imports System.Console

Module Module1

    Sub Main()

        ' First create two simple tables
        Dim petsTable As DataTable = New DataTable("Pets")
        petsTable.Columns.Add("OwnerName", System.Type.GetType("System.String"))
        petsTable.Columns.Add("PetName", System.Type.GetType("System.String"))

        Dim ownersTable As DataTable = New DataTable("Owners")
        ownersTable.Columns.Add("Name", System.Type.GetType("System.String"))

        ' Now set up the ForeignKeyConstraint, and add it to the parent table
        petsTable.Constraints.Add("PetsOwners", _
            ownersTable.Columns("Name"), petsTable.Columns("OwnerName"))

        ' Add the two tables to a Dataset - this lets us 'EnforceConstraints'
        Dim ds As DataSet = New DataSet()
        ds.Tables.Add(ownersTable)
        ds.Tables.Add(petsTable)
        ds.EnforceConstraints = True

        ' Now add in some data
        ownersTable.Rows.Add(New String() {"Miss Bloggs"})
        petsTable.Rows.Add(New String() {"Miss Bloggs", "Fluffy"})
        petsTable.Rows.Add(New String() {"Miss Bloggs", "Cuddles"})


        Dim ownerRow As DataRow = ownersTable.Rows(0)

        ShowPetsTable("Before changing owner name...", petsTable)

        ' Changing the owner name here will cause a cascading update on 
        ' the pet's table.
        ownerRow("Name") = "Mrs Jones"

        ShowPetsTable("After changing owner name...", petsTable)

        WriteLine("All done. Press Enter to exit")
        ReadLine()

    End Sub

    Private Sub ShowPetsTable(ByVal heading As String, ByVal petsTable As DataTable)
        Dim petRow As DataRow
        WriteLine(heading)
        For Each petRow In petsTable.Rows
            WriteLine(petRow("PetName").ToString() + _
                " is owned by " + petRow("OwnerName").ToString())
        Next
        WriteLine("")
    End Sub

End Module
