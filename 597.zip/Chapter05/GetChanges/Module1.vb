Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()

        Dim adapter As New SqlDataAdapter( _
            "SELECT * FROM Employees", _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        Dim ds As New DataSet()
        adapter.Fill(ds)

        Dim newRow As DataRow = ds.Tables(0).Rows(0)
        newRow("FirstName") = "Pete"

        Dim newDS As DataSet = ds.GetChanges()
        WriteLine("The original dataset had " + ds.Tables(0).Rows.Count.ToString() + _
            " rows of data.")
        WriteLine("The new dataset has " + newDS.Tables(0).Rows.Count.ToString())
        ReadLine()


    End Sub

End Module
