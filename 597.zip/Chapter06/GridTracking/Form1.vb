Imports System.Data.SqlClient


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(16, 8)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(560, 256)
        Me.DataGrid1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 272)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(560, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 350)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.DataGrid1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim northwindAdapter As New SqlDataAdapter( _
            "SELECT * FROM Employees", _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")
        Dim northwindDataset As New DataSet()

        northwindAdapter.Fill(northwindDataset, "employees")

        DataGrid1.SetDataBinding(northwindDataset, "employees")

    End Sub

    Private Sub DataGrid1_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGrid1.CurrentCellChanged
        Dim currentRow As Integer = DataGrid1.CurrentCell.RowNumber
        Dim currentColumn As Integer = DataGrid1.CurrentCell.ColumnNumber

        'Label1.Text = "Changed to cell at " + _
        '            currentRow.ToString() + ", " + _
        '            currentColumn.ToString() + ". Value of cell is " + _
        '            DataGrid1.Item(DataGrid1.CurrentCell).ToString()
        Dim gridDS As DataSet = DataGrid1.DataSource
        Dim gridTable As DataTable = gridDS.Tables(DataGrid1.DataMember)

        Dim currentEmployee() As DataRow = gridTable.Select("EmployeeID=" + _
                    DataGrid1.Item(currentRow, 0).ToString(), "", DataViewRowState.CurrentRows)

        Label1.Text = currentEmployee(0).Item("FirstName") + _
                    " " + currentEmployee(0).Item("LastName")



    End Sub



End Class
