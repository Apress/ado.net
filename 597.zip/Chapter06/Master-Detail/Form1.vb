Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents employeeAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents northwindConnection As System.Data.SqlClient.SqlConnection
    Friend WithEvents regionAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents northwindDS As Master_Detail.TEmployeeRegionDS
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.employeeAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.northwindConnection = New System.Data.SqlClient.SqlConnection()
        Me.regionAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand()
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.northwindDS = New Master_Detail.TEmployeeRegionDS()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        CType(Me.northwindDS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'employeeAdapter
        '
        Me.employeeAdapter.SelectCommand = Me.SqlSelectCommand1
        Me.employeeAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Employees", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("Title", "Title"), New System.Data.Common.DataColumnMapping("EmployeeID", "EmployeeID"), New System.Data.Common.DataColumnMapping("RegionID", "RegionID"), New System.Data.Common.DataColumnMapping("RegionDescription", "RegionDescription")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT DISTINCT Employees.LastName, Employees.FirstName, Employees.Title, Employe" & _
        "es.EmployeeID, Region.RegionID, Region.RegionDescription FROM Employees INNER JO" & _
        "IN EmployeeTerritories ON Employees.EmployeeID = EmployeeTerritories.EmployeeID " & _
        "INNER JOIN Territories ON EmployeeTerritories.TerritoryID = Territories.Territor" & _
        "yID INNER JOIN Region ON Territories.RegionID = Region.RegionID"
        Me.SqlSelectCommand1.Connection = Me.northwindConnection
        '
        'northwindConnection
        '
        Me.northwindConnection.ConnectionString = "data source=SARATOGA;initial catalog=Northwind;integrated security=SSPI;persist s" & _
        "ecurity info=False;workstation id=SARATOGA;packet size=4096"
        '
        'regionAdapter
        '
        Me.regionAdapter.DeleteCommand = Me.SqlDeleteCommand1
        Me.regionAdapter.InsertCommand = Me.SqlInsertCommand1
        Me.regionAdapter.SelectCommand = Me.SqlSelectCommand2
        Me.regionAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Region", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("RegionID", "RegionID"), New System.Data.Common.DataColumnMapping("RegionDescription", "RegionDescription")})})
        Me.regionAdapter.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM Region WHERE (RegionID = @Original_RegionID) AND (RegionDescription =" & _
        " @Original_RegionDescription)"
        Me.SqlDeleteCommand1.Connection = Me.northwindConnection
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RegionID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RegionID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RegionDescription", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RegionDescription", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO Region(RegionID, RegionDescription) VALUES (@RegionID, @RegionDescrip" & _
        "tion); SELECT RegionID, RegionDescription FROM Region WHERE (RegionID = @RegionI" & _
        "D)"
        Me.SqlInsertCommand1.Connection = Me.northwindConnection
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RegionID", System.Data.SqlDbType.Int, 4, "RegionID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RegionDescription", System.Data.SqlDbType.NVarChar, 50, "RegionDescription"))
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT RegionID, RegionDescription FROM Region"
        Me.SqlSelectCommand2.Connection = Me.northwindConnection
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE Region SET RegionID = @RegionID, RegionDescription = @RegionDescription WH" & _
        "ERE (RegionID = @Original_RegionID) AND (RegionDescription = @Original_RegionDes" & _
        "cription); SELECT RegionID, RegionDescription FROM Region WHERE (RegionID = @Reg" & _
        "ionID)"
        Me.SqlUpdateCommand1.Connection = Me.northwindConnection
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RegionID", System.Data.SqlDbType.Int, 4, "RegionID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RegionDescription", System.Data.SqlDbType.NVarChar, 50, "RegionDescription"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RegionID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RegionID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RegionDescription", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RegionDescription", System.Data.DataRowVersion.Original, Nothing))
        '
        'northwindDS
        '
        Me.northwindDS.DataSetName = "TEmployeeRegionDS"
        Me.northwindDS.EnforceConstraints = False
        Me.northwindDS.Locale = New System.Globalization.CultureInfo("en-GB")
        Me.northwindDS.Namespace = "http://www.tempuri.org/TEmployeeRegionDS.xsd"
        '
        'ListBox1
        '
        Me.ListBox1.DataSource = Me.northwindDS
        Me.ListBox1.DisplayMember = "Region.RegionDescription"
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(12, 13)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(345, 116)
        Me.ListBox1.TabIndex = 0
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = "Region.RegionEmployees"
        Me.DataGrid1.DataSource = Me.northwindDS
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(12, 133)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(614, 337)
        Me.DataGrid1.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(640, 481)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.DataGrid1, Me.ListBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.northwindDS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DataGrid1_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles DataGrid1.Navigate

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        employeeAdapter.Fill(northwindDS)
        regionAdapter.Fill(northwindDS)

    End Sub
End Class
