Imports System.Data.SqlClient


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents acceptButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        Me.acceptButton = New System.Windows.Forms.Button()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 8)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(272, 248)
        Me.DataGrid1.TabIndex = 0
        '
        'acceptButton
        '
        Me.acceptButton.Location = New System.Drawing.Point(152, 264)
        Me.acceptButton.Name = "acceptButton"
        Me.acceptButton.Size = New System.Drawing.Size(112, 23)
        Me.acceptButton.TabIndex = 1
        Me.acceptButton.Text = "AcceptChanges"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 335)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.acceptButton, Me.DataGrid1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region


    
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim northwindDataset As New DataSet()

        Dim regionAdapter As New SqlDataAdapter( _
                "SELECT * FROM Region", _
                "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        regionAdapter.Fill(northwindDataset, "region")
        AddHandler northwindDataset.Tables("region").RowChanging, _
            New Data.DataRowChangeEventHandler(AddressOf ValidateData)

        DataGrid1.SetDataBinding(northwindDataset, "region")

    End Sub

    Private Sub ValidateData(ByVal sender As Object, _
        ByVal e As DataRowChangeEventArgs)

        If e.Row("RegionDescription", DataRowVersion.Proposed) = "Peter" Then
            e.Row.SetColumnError("RegionDescription", _
                "Cannot set the description field to 'Peter'")

        End If

    End Sub

    Private Sub acceptButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles acceptButton.Click
        ' First, get the dataset
        Dim ds As DataSet = DataGrid1.DataSource

        If ds.HasErrors Then

            Dim errorRow As DataRow
            For Each errorRow In ds.Tables("region").GetErrors()

                Dim errorColumn As DataColumn
                For Each errorColumn In errorRow.GetColumnsInError()

                    MessageBox.Show("Column " + errorColumn.ColumnName + _
                        " cannot be changed to " + errorRow(errorColumn.ColumnName, DataRowVersion.Current).ToString(), _
                        errorRow.GetColumnError(errorColumn.Ordinal))

                Next

                errorRow.RejectChanges()
                errorRow.ClearErrors()

            Next
        End If

        ds.AcceptChanges()

    End Sub
End Class

