Option Strict On
Imports System.Data.SqlClient


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents previousButton As System.Windows.Forms.Button
    Friend WithEvents nextButton As System.Windows.Forms.Button
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.previousButton = New System.Windows.Forms.Button()
        Me.nextButton = New System.Windows.Forms.Button()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(42, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 15)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(81, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Title"
        '
        'previousButton
        '
        Me.previousButton.Location = New System.Drawing.Point(18, 140)
        Me.previousButton.Name = "previousButton"
        Me.previousButton.TabIndex = 1
        Me.previousButton.Text = "Previous"
        '
        'nextButton
        '
        Me.nextButton.Location = New System.Drawing.Point(268, 140)
        Me.nextButton.Name = "nextButton"
        Me.nextButton.TabIndex = 1
        Me.nextButton.Text = "Next"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(116, 34)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(227, 22)
        Me.txtFirstName.TabIndex = 2
        Me.txtFirstName.Text = "TextBox1"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(116, 69)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(227, 22)
        Me.txtLastName.TabIndex = 2
        Me.txtLastName.Text = "TextBox1"
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(116, 104)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(227, 22)
        Me.txtTitle.TabIndex = 2
        Me.txtTitle.Text = "TextBox1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(361, 174)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFirstName, Me.previousButton, Me.Label1, Me.Label2, Me.Label3, Me.nextButton, Me.txtLastName, Me.txtTitle})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Dim currencyMgr As CurrencyManager

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Set up the DataAdapter in the usual way.
        Dim employeeAdapter As New SqlDataAdapter( _
            "SELECT * FROM Employees", _
            "Data Source=localhost;Initial Catalog=northwind;Integrated Security=SSPI")

        ' Create a dataset for the Northwind Database and fill it with the employee info
        Dim northwindDS As New DataSet("northwind")
        employeeAdapter.Fill(northwindDS, "Employees")

        '----- now we can go ahead and set up the bindings
        txtFirstName.DataBindings.Add("Text", _
            northwindDS.Tables("Employees"), "Firstname")
        txtLastName.DataBindings.Add("Text", _
            northwindDS.Tables("Employees"), "Lastname")
        txtTitle.DataBindings.Add("Text", _
            northwindDS.Tables("Employees"), "Title")

        currencyMgr = CType(Me.BindingContext(northwindDS.Tables("Employees")), _
            CurrencyManager)

    End Sub

    Private Sub nextButton_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles nextButton.Click
        If currencyMgr.Position < currencyMgr.Count - 1 Then
            currencyMgr.Position = currencyMgr.Position + 1
        End If
    End Sub

    Private Sub previousButton_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles previousButton.Click
        If currencyMgr.Position > 0 Then
            currencyMgr.Position = currencyMgr.Position - 1
        End If
    End Sub
End Class
