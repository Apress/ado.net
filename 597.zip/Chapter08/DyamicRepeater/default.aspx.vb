Option Strict On
Imports System.Data.SqlClient


Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents tableButton As System.Web.UI.WebControls.Button
    Protected WithEvents listButton As System.Web.UI.WebControls.Button
    Protected WithEvents tableRepeater As System.Web.UI.WebControls.Repeater
    Protected WithEvents listRepeater As System.Web.UI.WebControls.Repeater
    Protected WithEvents employeeRepeater As System.Web.UI.WebControls.Repeater

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub tableButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tableButton.Click
        ' Set up the repeater's templates to show a table
        employeeRepeater.HeaderTemplate = tableRepeater.HeaderTemplate
        employeeRepeater.AlternatingItemTemplate = tableRepeater.AlternatingItemTemplate
        employeeRepeater.ItemTemplate = tableRepeater.ItemTemplate
        employeeRepeater.FooterTemplate = tableRepeater.FooterTemplate
        ReBindRepeater()
    End Sub

    Private Sub ReBindRepeater()
        Dim selectCommand As New SqlCommand( _
            "SELECT Firstname, LastName, Title FROM Employees", _
            GetConnection())

        selectCommand.Connection.Open()
        Dim employeeReader As SqlDataReader = _
            selectCommand.ExecuteReader()

        employeeRepeater.DataSource = employeeReader
        employeeRepeater.DataBind()

        selectCommand.Connection.Close()
    End Sub

    Private Function GetConnection() As SqlConnection
        Dim con As New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")
        Return con
    End Function

   
    Private Sub listButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listButton.Click
        employeeRepeater.HeaderTemplate = listRepeater.HeaderTemplate
        employeeRepeater.AlternatingItemTemplate = listRepeater.AlternatingItemTemplate
        employeeRepeater.ItemTemplate = listRepeater.ItemTemplate
        employeeRepeater.FooterTemplate = listRepeater.FooterTemplate
        ReBindRepeater()
    End Sub
End Class
