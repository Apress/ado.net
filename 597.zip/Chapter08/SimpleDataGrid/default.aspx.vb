Option Strict On
Imports System.Data.SqlClient


Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents employeeGrid As System.Web.UI.WebControls.DataGrid
    Protected WithEvents addButton As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            ReBindGrid()
        End If
    End Sub


    Private Sub ReBindGrid()
        ' Sets up the grid bindings. This will be the first thing
        ' done when the page is loaded, and the last thing done
        ' after a page is posted back (prior to sending it out to 
        ' the user's browser again). 
        Dim northwindDS As DataSet = GetDataset()
        employeeGrid.DataSource = northwindDS
        employeeGrid.DataMember = "Employees"
        employeeGrid.DataBind()
    End Sub


    Private Function GetDataset() As DataSet
        ' First create the data adapater
        Dim employeeAdapter As New SqlDataAdapter( _
            "SELECT EmployeeID, FirstName, LastName, Title FROM Employees", _
            GetConnection())
        ' Now you can build and fill the dataset
        Dim northwindDS As New DataSet("Northwind")
        employeeAdapter.Fill(northwindDS, "Employees")
        Return northwindDS
    End Function

    Private Function GetConnection() As SqlConnection
        ' Connections are used to build the dataset to bind to, 
        ' as well as with the commands that perform database 
        ' updates, so it's a good idea to contain the connection
        ' creation code in its own independant function
        Dim con As New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")
        Return con
    End Function

    Private Sub employeeGrid_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles employeeGrid.EditCommand
        ' When the user clicks on the edit command, the page
        ' is posted back. We need to set the edit row index
        ' to put the grid into edit mode
        employeeGrid.EditItemIndex = e.Item.ItemIndex

        ' Before the page is sent back to the user, rebind the 
        ' grid. Failure to do this will result in the edit
        ' boxes being empty.
        ReBindGrid()
    End Sub

    Private Sub employeeGrid_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles employeeGrid.CancelCommand
        ' When the user clicks on the Cancel button in edit
        ' mode, the page is posted back. We need to pull the
        ' grid out of edit mode, and rebind it. 
        employeeGrid.EditItemIndex = -1
        ReBindGrid()
    End Sub

    Private Sub employeeGrid_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles employeeGrid.UpdateCommand
        ' When the employee clicks on the Update button
        ' a number of things need to happen. We need
        ' to extract the data from the text boxes in the 
        ' grid in order to run an update or insert command, and 
        ' then drop the grid out of edit mode. 
        ' Finally, the grid needs to be rebound to pick up 
        ' the changes just made to the database. 

        Dim employeeID As Long
        Try
            employeeID = Long.Parse(e.Item.Cells(2).Text)
        Catch
            employeeID = -1
        End Try

        Dim newFirstName As String = CType(e.Item.Cells(3).Controls(0), TextBox).Text
        Dim newLastName As String = CType(e.Item.Cells(4).Controls(0), TextBox).Text
        Dim newTitle As String = CType(e.Item.Cells(5).Controls(0), TextBox).Text

        If employeeID > -1 Then
            ' Now for the update - best to use a parameterized command
            ' or stored procedure here, to get around problem of users 
            ' enter ' symbols in the text
            Dim updateCommand As New SqlCommand( _
                "UPDATE Employees SET " + _
                "FirstName = @Firstname, LastName = @Lastname, " + _
                "Title = @Title WHERE EmployeeID = @EmployeeID", _
                GetConnection())

            With updateCommand
                .Parameters.Add("@EmployeeID", employeeID)
                .Parameters.Add("@Firstname", newFirstName)
                .Parameters.Add("@Lastname", newLastName)
                .Parameters.Add("@Title", newTitle)

                .Connection.Open()
                .ExecuteNonQuery()
                .Connection.Close()
            End With
        Else
            ' An insert is needed
            Dim insertCommand As New SqlCommand( _
                "INSERT INTO Employees (FirstName, LastName, Title) " + _
                "VALUES(@FirstName, @LastName, @Title)", _
                GetConnection())
            With insertCommand
                .Parameters.Add("@FirstName", newFirstName)
                .Parameters.Add("@LastName", newLastName)
                .Parameters.Add("@Title", newTitle)
                .Connection.Open()
                .ExecuteNonQuery()
                .Connection.Close()
            End With
        End If
        employeeGrid.EditItemIndex = -1
        ReBindGrid()
    End Sub

    Private Sub employeeGrid_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles employeeGrid.DeleteCommand
        ' When the delete link is clicked, we need to delete the current row
        ' (in a live app check that the user really does want to delete), 
        ' and rebind the grid before sending it back to the user.
        Dim EmployeeID As Long = Long.Parse(e.Item.Cells(2).Text)
        Dim deleteCommand As New SqlCommand( _
            "DELETE FROM Employees WHERE EmployeeID = @EmployeeID", _
            GetConnection())
        With deleteCommand
            .Parameters.Add("@EmployeeID", EmployeeID)
            .Connection.Open()
            .ExecuteNonQuery()
            .Connection.Close()
        End With
        ReBindGrid()
    End Sub

    Private Sub addButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addButton.Click
        ' When the user chooses to add a new item into the grid, 
        ' we need to rebuild the dataset, add a blank row to it, 
        ' then set the grid into edit mode on the new row
        Dim northwindDS As DataSet = GetDataset()
        northwindDS.Tables("Employees").Rows.Add( _
            northwindDS.Tables("Employees").NewRow())
        employeeGrid.EditItemIndex = northwindDS.Tables("Employees").Rows.Count - 1
        employeeGrid.DataSource = northwindDS
        employeeGrid.DataMember = "Employees"
        employeeGrid.DataBind()
    End Sub

    Private Sub employeeGrid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles employeeGrid.SelectedIndexChanged

    End Sub

    Private Sub employeeGrid_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles employeeGrid.PageIndexChanged

    End Sub
End Class
