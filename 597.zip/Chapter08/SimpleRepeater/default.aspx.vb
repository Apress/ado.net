Option Strict On
Imports System.Data.SqlClient


Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents employeeRepeater As System.Web.UI.WebControls.Repeater

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            RebindRepeater()
        End If
    End Sub

    Private Sub RebindRepeater()
        ' Set up a command to grab the data
        Dim selectCommand As New SqlCommand( _
            "SELECT Firstname, Lastname, Title From Employees", _
            GetConnection())

        selectCommand.Connection.Open()

        Dim employeeReader As SqlDataReader = selectCommand.ExecuteReader()
        employeeRepeater.DataSource = employeeReader
        employeeRepeater.DataBind()
        selectCommand.Connection.Close()

    End Sub

    Private Function GetConnection() As SqlConnection
        Dim con As New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")
        Return con
    End Function

End Class
