Option Strict On
Imports System.Data.SqlClient
Imports System.Console


Module Module1

    Sub Main()

        Dim northwindConnection As New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")

        northwindConnection.Open()

        Dim readerTransaction As SqlTransaction = _
            northwindConnection.BeginTransaction(IsolationLevel.ReadUncommitted)

        Dim selectCommand As New SqlCommand( _
            "SELECT * FROM Region", northwindConnection, readerTransaction)


        Dim repeatRead As Boolean = True
        While (repeatRead)
            Try
                Dim regionReader As SqlDataReader = selectCommand.ExecuteReader()

                While (regionReader.Read())
                    WriteLine("ID : " + regionReader.GetValue(0).ToString() + _
                        ", Description : " + regionReader.GetString(1))
                End While
                regionReader.Close()

            Catch ex As SqlException
                WriteLine("The command timed out")
            End Try

            Write("Do you want to read again (Y/N) : ")
            repeatRead = (ReadLine().ToUpper() = "Y")

        End While

        readerTransaction.Rollback()
        northwindConnection.Close()

    End Sub

End Module
