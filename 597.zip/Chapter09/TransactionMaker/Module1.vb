Option Strict On
Imports System.Data.SqlClient
Imports System.Console


Module Module1

    Sub Main()

        Dim northwindConnection As New SqlConnection( _
            "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")
        northwindConnection.Open()

        Dim updateTransaction As SqlTransaction = _
            northwindConnection.BeginTransaction(IsolationLevel.Serializable)

        Try

            Dim updateCommand As New SqlCommand( _
                "UPDATE Region SET RegionDescription = 'Some arbitrary value' " + _
                "WHERE Region.RegionId = 1", _
                northwindConnection, updateTransaction)
            updateCommand.ExecuteNonQuery()

            Dim insertCommand As New SqlCommand( _
                "INSERT INTO REGION (RegionID, RegionDescription) " + _
                "VALUES (150, 'Phantom Region')", _
                northwindConnection, updateTransaction)
            insertCommand.ExecuteNonQuery()


            WriteLine("Update complete. Hit Return to rollback")
            ReadLine()

        Catch ex As Exception
            WriteLine("Something went horribly wrong - " + ex.ToString())
        End Try

        updateTransaction.Rollback()

        WriteLine("All done! Press Enter to exit")
        ReadLine()

    End Sub

End Module
