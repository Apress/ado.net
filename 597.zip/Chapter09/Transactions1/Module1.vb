Option Strict On
Imports System.Data.SqlClient
Imports System.Console

Module Module1

    Sub Main()
        Try
            ' First set up a connection to the database - we can
            ' use this to get a transaction running
            Dim northwindConnection As New SqlConnection( _
                "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=SSPI")
            northwindConnection.Open()
            Dim deleteTransaction As SqlTransaction = northwindConnection.BeginTransaction()
            ' Print out how many order details are in the database
            PrintOrderDetailCount(northwindConnection, deleteTransaction)
            ' Now delete all the order detail records and print the count again
            Dim deleteCommand As New SqlCommand( _
                "DELETE FROM [order details]", northwindConnection, deleteTransaction)
            WriteLine(deleteCommand.ExecuteNonQuery().ToString() + " order details deleted!")
            PrintOrderDetailCount(northwindConnection, deleteTransaction)
            ' Rollback the transaction and count the order details once again
            deleteTransaction.Rollback()
            WriteLine("Rollback complete")
            PrintOrderDetailCount(northwindConnection, deleteTransaction)
        Catch ex As Exception
            WriteLine(ex.ToString())
        End Try
        WriteLine("All done! Press Enter to exit.")
        ReadLine()

    End Sub

    Private Sub PrintOrderDetailCount(ByVal con As SqlConnection, ByVal trans As SqlTransaction)
        Dim selectCommand As New SqlCommand( _
            "SELECT COUNT(*) FROM [Order details]", con, trans)
        WriteLine("There are currently " + selectCommand.ExecuteScalar().ToString() + _
            " order details in the database")
    End Sub


End Module
