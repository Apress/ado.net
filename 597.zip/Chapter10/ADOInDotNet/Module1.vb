Option Strict On
Imports ADODB


Module Module1

    Sub Main()

        Dim adoRecordset As New ADODB.Recordset()
        adoRecordset.Open("SELECT * FROM Region", _
            "Provider=SQLOLEDB;Data Source=localhost;Initial Catalog=Northwind;" + _
            "User ID=sa;Password=Password")

        Do While Not adoRecordset.EOF
            System.Console.WriteLine(adoRecordset.Fields("RegionDescription").Value)
            adoRecordset.MoveNext()
        Loop

        adoRecordset.Close()
        System.Console.WriteLine("All done! Hit return to exit")
        System.Console.ReadLine()

    End Sub

End Module
