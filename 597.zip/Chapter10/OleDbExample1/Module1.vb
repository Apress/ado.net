Option Strict On
Imports System.Data.OleDb
Imports System.Console


Module Module1

    Sub Main()

        Dim northwindConnection As New OleDbConnection( _
            "Provider=SQLOLEDB;Data Source=localhost;Intial Catalog=Northwind;" + _
            "Integrated Security=SSPI")

        northwindConnection.Open()

        WriteLine("Provider is " + northwindConnection.Provider)
        WriteLine("Database is " + northwindConnection.Database)
        WriteLine("Data source is " + northwindConnection.DataSource)
        WriteLine("Connection state is " + northwindConnection.State.ToString())

        northwindConnection.Close()

        WriteLine("All done! Hit return to exit")
        ReadLine()

    End Sub

End Module
