Imports System.Xml


Module Module1

    Sub Main()
        ' Create an empty XML document
        Dim composerDoc As New XmlDocument()
        ' Add in the document node ("<Composers/"). You could achieve the same
        ' thing with a call to composerDoc.LoadXml("<Composers/>")
        Dim composers As XmlElement = composerDoc.CreateElement("Composers")
        composerDoc.AppendChild(composers)

        Dim composerElement As XmlElement

        ' Ask the document for a new element, which we'll use to hold an individual 
        ' composer.
        composerElement = composerDoc.CreateElement("Composer")
        ' Set up the child text node to hold the name of the composer.
        composerElement.AppendChild(composerDoc.CreateTextNode("Franz Joseph Haydn"))
        ' Now we can use some attributes to set up the year the composer was born
        ' and died. 
        composerElement.SetAttribute("Born", "1732")
        composerElement.SetAttribute("Died", "1809")
        ' Finally, add the composer element as a child of the document node
        composers.AppendChild(composerElement)

        ' All that remains now is to take a look at our document
        composerDoc.Save(Console.Out)

        Console.WriteLine()
        Console.WriteLine("All done! Hit return to exit")
        Console.ReadLine()

    End Sub

End Module
