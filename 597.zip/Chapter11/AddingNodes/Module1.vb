Imports System.Xml


Module Module1

    Sub Main()
        Dim composerDoc As New XmlDocument()
        composerDoc.LoadXml("<Composers/>")
        Dim composers As XmlElement = composerDoc.DocumentElement

        Dim composerElement As XmlElement

        composerElement = composerDoc.CreateElement("Composer")
        composerElement.AppendChild(composerDoc.CreateTextNode("Franz Joseph Haydn"))
        composers.AppendChild(composerElement)

        composerElement = composerDoc.CreateElement("Composer")
        composerElement.AppendChild(composerDoc.CreateTextNode("Wolfgang Amadeus Mozart"))
        composers.AppendChild(composerElement)

        composerDoc.Save(Console.Out)

        Console.WriteLine()
        Console.WriteLine("All done! Hit return to exit")
        Console.ReadLine()

    End Sub

End Module
