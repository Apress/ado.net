Option Strict On
Imports System.Xml

Module Module1

    Sub Main()

        ' Create an empty XmlDocument and set it's document node
        Dim DvdDocument As New XmlDocument()
        DvdDocument.AppendChild(DvdDocument.CreateElement("dvd-collection"))

        ' Create a DVD node and add attributes to it to identify
        ' the movie in question. Finally, add the node as a child
        ' of the document node.
        Dim DvdTitle As XmlElement
        DvdTitle = DvdDocument.CreateElement("DVD")
        DvdTitle.SetAttribute("SoundFormat", "DTS")
        DvdTitle.SetAttribute("Title", "Mission Impossible")
        DvdDocument.DocumentElement.AppendChild(DvdTitle)

        ' Now create a new star for this dvd
        DvdTitle.AppendChild(DvdDocument.CreateElement("Star"))

        ' Set up the actor and character nodes of the star
        Dim actor As XmlElement = DvdDocument.CreateElement("Actor")
        actor.AppendChild(DvdDocument.CreateTextNode("Tom Cruise"))
        Dim character As XmlElement = DvdDocument.CreateElement("Character")
        character.AppendChild(DvdDocument.CreateTextNode("Ethan Hunt"))

        ' Add the actor and character nodes as children of
        ' the star node
        DvdTitle.FirstChild.AppendChild(actor)
        DvdTitle.FirstChild.AppendChild(character)

        ' Last but not least, write out the document to the console
        DvdDocument.Save(Console.Out)
        Console.WriteLine()
        Console.WriteLine("All done! Hit return to exit.")
        Console.ReadLine()

    End Sub

End Module
