Option Strict On
Imports System.Xml

Module Module1

    Sub Main()
        ' First, lets build an XmlDocument from XML embedded in code
        Dim musicDoc As New XmlDocument()
        musicDoc.LoadXml( _
            "<Music>" + _
            "<Track Composer='Haydn' Date='1796'>Trumpet Concerto in E Flat</Track>" + _
            "<Track Composer='Beethoven' Date='1796'>Minuet in G</Track>" + _
            "<Track Composer='Beethoven' Date='1808'>Symphony No. 5</Track>" + _
            "</Music>")

        ' Now we can iterate through the nodes within this document
        Dim track As XmlElement
        For Each track In musicDoc.DocumentElement.GetElementsByTagName("Track")
            If track.HasAttribute("Composer") Then
                Console.WriteLine("Composer :" + track.GetAttribute("Composer"))
            End If

            If track.HasAttribute("Date") Then
                Console.WriteLine("Date Composed :" + track.GetAttribute("Date"))
            End If
            ' The value of the node is actually 'Track'. To get at the child
            ' Xml Text node, we need to use FirstChild and print its value
            If track.HasChildNodes() Then
                If track.FirstChild.NodeType = XmlNodeType.Text Then
                    Console.WriteLine("Title of piece : " + track.FirstChild.Value)
                End If
            End If
            Console.WriteLine()
        Next

        ' Saving to the console's out-stream will print out a formatted
        ' xml document.
        musicDoc.Save(Console.Out)

        Console.WriteLine()
        Console.WriteLine("All done! Press enter to exit")
        Console.ReadLine()

    End Sub

End Module
