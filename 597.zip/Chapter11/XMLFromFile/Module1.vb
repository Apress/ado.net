Option Strict On
Imports System.Xml
Imports System.IO


Module Module1

    Sub Main()

        ' First find out where the file lives. If you put it in the My Documents folder, 
        ' we can ask the system where that folder is. 
        Dim fileName As String = _
            Environment.GetFolderPath(Environment.SpecialFolder.Personal) + _
            "\Music.xml"

        Dim xmlStream As New FileStream(fileName, FileMode.Open)
        Dim musicDocument As New XmlDocument()

        musicDocument.Load(xmlStream)
        musicDocument.Save(Console.Out)

        Console.WriteLine()
        Console.WriteLine("All done! Press Enter to exit")
        Console.ReadLine()
    End Sub

End Module
