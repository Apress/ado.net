Option Strict On
Imports System.Data.SqlClient


Module Module1

    Sub Main()

        Dim regionAdapter As New SqlDataAdapter( _
            "SELECT * FROM Region", _
            "Data Source=localhost;" + _
            "Initial Catalog=Northwind; " + _
            "Integrated Security=SSPI")
        Dim territoriesAdapter As New SqlDataAdapter( _
            "SELECT * FROM Territories", _
            "Data Source=localhost;" + _
            "Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")

        Dim northwindDS As New DataSet("Northwind")
        regionAdapter.Fill(northwindDS, "Region")
        territoriesAdapter.Fill(northwindDS, "Territories")

        northwindDS.Relations.Add("RegionTerritories", _
            northwindDS.Tables("Region").Columns("RegionID"), _
        northwindDS.Tables("Territories").Columns("RegionID"))


        northwindDS.Relations("RegionTerritories").Nested = True

        northwindDS.WriteXml("regionterritories.xml", XmlWriteMode.WriteSchema)

        Console.WriteLine("All done. Press enter to exit")
        Console.ReadLine()

    End Sub

End Module
