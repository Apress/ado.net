Imports System.Data.SqlClient


Module Module1

    Sub Main()

        Dim regionAdapter As New SqlDataAdapter( _
            "SELECT * FROM Region", _
            "Data Source=HORATIO\VSdotNET; " + _
            "Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")
        Dim northwindDS As New DataSet("Northwind")
        regionAdapter.Fill(northwindDS, "Region")

        System.Console.WriteLine(northwindDS.GetXml())
        System.Console.ReadLine()

        System.Console.WriteLine(northwindDS.GetXmlSchema())
        System.Console.ReadLine()

        northwindDS.WriteXml(Console.Out, XmlWriteMode.WriteSchema)
        System.Console.ReadLine()

    End Sub

End Module
