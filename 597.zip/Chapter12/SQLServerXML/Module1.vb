Option Strict On
Imports System.Data.SqlClient

Module Module1

    Sub Main()

        Dim regionSchemaCommand As New SqlCommand( _
            "SELECT * FROM Region FOR XML AUTO,XMLDATA", _
            New SqlConnection( _
            "Data Source=localhost;" + _
            "Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI"))
        regionSchemaCommand.Connection.Open()

        Dim schemaReader As Xml.XmlReader = _
            regionSchemaCommand.ExecuteXmlReader()

        Dim northwindDS As New DataSet("Northwind")
        northwindDS.ReadXmlSchema(schemaReader)

        regionSchemaCommand.Connection.Close()
        northwindDS.WriteXmlSchema(Console.Out)
        Console.ReadLine()

        northwindDS.ReadXml("regionterritories.xml", _
            XmlReadMode.IgnoreSchema)
        Console.WriteLine(northwindDS.GetXml())
        Console.ReadLine()

    End Sub

End Module
