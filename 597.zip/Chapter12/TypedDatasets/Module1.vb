Option Strict On
Imports System.Data.SqlClient


Module Module1

    Sub Main()

        '-- First, load data into our typed dataset
        Dim northwindDataset As New NorthwindDS()
        northwindDataset.EnforceConstraints = False
        BuildDataset(northwindDataset._Region, _
            "SELECT * FROM Region")
        BuildDataset(northwindDataset.Territories, _
            "SELECT * FROM Territories")
        BuildDataset(northwindDataset.EmployeeTerritories, _
            "SELECT * FROM EmployeeTerritories")
        BuildDataset(northwindDataset.Employees, _
            "SELECT * FROM Employees")


        '-- Start looping through the regions
        Dim currentRegion As NorthwindDS._RegionRow
        For Each currentRegion In northwindDataset._Region
            System.Console.WriteLine( _
                "Region : {0}", currentRegion.RegionDescription)

            '-- Now loop through each territory in each region
            Dim currentTerritory As NorthwindDS.TerritoriesRow
            For Each currentTerritory In _
              currentRegion.GetTerritoriesRows()
                System.Console.WriteLine( _
                    "    Territory : {0}", _
                    currentTerritory.TerritoryDescription)

                ' Resolve the link between employee and territory
                Dim currentEmployeeID As NorthwindDS.EmployeeTerritoriesRow
                For Each currentEmployeeID In _
                  currentTerritory.GetEmployeeTerritoriesRows()

                    ' Print the employee that services this territory
                    Dim currentEmployee As NorthwindDS.EmployeesRow
                    For Each currentEmployee In _
                      currentEmployeeID.GetEmployeesRows()
                        System.Console.WriteLine( _
                            "        Employee : {0} {1}", _
                            currentEmployee.FirstName, _
                            currentEmployee.LastName)
                    Next

                Next

            Next

        Next

        System.Console.ReadLine()

    End Sub
    Private Sub BuildDataset(ByVal tableToFill As DataTable, _
        ByVal selectCommand As String)
        Dim dataAdapter As New SqlDataAdapter( _
            New SqlCommand(selectCommand, GetConnection()))
        dataAdapter.Fill(tableToFill)
    End Sub

    Private Function GetConnection() As SqlConnection
        Dim connection As New SqlConnection( _
            "Data Source=localhost;" + _
            "Initial Catalog=Northwind;" + _
            "Integrated Security=SSPI")
        Return connection
    End Function

End Module
