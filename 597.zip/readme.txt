ADO.NET NOVICE TO PRO, VB.NET EDITION 
BY PETER WRIGHT
EXAMPLE CODE
-------------------------------------

In this zip are all the code examples from the book. The examples are designed to demonstrate principles of ADO.NET in each chapter of the book. They are not intended as examples of how a good program should be designed or written. Where a decision had to be made as to whether an example should be elegant or 'clear', the latter was chosen. So please, no emails telling me off for inefficient code. Read the book along with the code and all will make sense. 

In order to compile and run the code, you will have to make some changes. First up, the connection strings. As the book explains, you will need to modify the Data Source in the the code examples to match your own database. As the book explains, you can find out the correct name of your Data Source setting by looking at the Server Explorer in Visual Studio.NET. 

Finally, the Chapter 8 examples are ASP.NET examples. Without setting up the correct web directory on your local IIS server it is unlikely that you will be able to load the projects into Visual Studio.NET without any errors. Instead, use Visual Studio.NET to create new ASP.NET projects and then add the VB.NET Source files to your own projects in order to run them. Once again, don't forget to change the Data Source in the connection strings. 


SUPPORT
-------
I am aware that there will be one or two people who have problems with the code. Perhaps there are bugs that cause serious problems in production code that I overlooked. Perhaps the code just won't run when Microsoft release patches and updates to Visual Studio.NET. 

For those situations, feel free to drop me an email and I'll do what I can to post updates. You can find updates to the code on www.apress.com, as well as on my own site www.codemonkey.demon.co.uk.  Please bear in mind though that I am a busy guy and it's hard, if not impossible, for me to respond to general queries about your own projects, nor produce extra sample code to help you through your own project problems. I'll try where I can, but no guarantees. 




Good luck on your journey through ADO.NET. 

Peter Wright
Eastbourne, England. August 2002
pete@codemonkey.demon.co.uk
www.codemonkey.demon.co.uk

